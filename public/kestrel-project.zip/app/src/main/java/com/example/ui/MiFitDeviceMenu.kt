package com.example.ui

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ble.ConnectionStatus
import com.example.ble.DiscoveredBand
import com.example.ble.MiBandState

// Kestrel Web App Theme Colors (matching web app :root theme)
private val KestrelBg = Color(0xFFFFEED7) // --page-bg: #FFEED7 Warm Cream
private val KestrelCard = Color(0xFFFFFFFF) // --card-soft: #ffffff White glass card
private val KestrelCardLight = Color(0xFFFBF7F2) // Subtle warm tinted inner card
private val KestrelBorder = Color(0x33AA98A9) // --line: rgba(170, 152, 169, 0.28)
private val KestrelMauve = Color(0xFFAA98A9) // --hero-mid: #AA98A9 Dusty Mauve
private val KestrelMauveDark = Color(0xFF7A6879) // --teal-deep: #7A6879 Deep Mauve
private val KestrelLilac = Color(0xFFC4B3C2) // --hero-top: #C4B3C2
private val KestrelCream = Color(0xFFFFEED7) // --cream: #FFEED7
private val KestrelText = Color(0xFF3D3340) // --ink: #3d3340 Deep Plum Ink
private val KestrelMuted = Color(0x993D3340) // --muted: rgba(61,51,64,0.55)

@Composable
fun MiFitDeviceMenuDialog(
  uiState: MiBandState,
  discoveredDevices: List<DiscoveredBand>,
  onScanClick: () -> Unit,
  onStopScanClick: () -> Unit,
  onConnectClick: (DiscoveredBand, String) -> Unit,
  onDisconnectClick: () -> Unit,
  onSaveAuthKey: (String) -> Unit,
  onSyncAllDataClick: () -> Unit = {},
  onReopenOnboarding: () -> Unit = {},
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  var inputAuthKey by remember(uiState.authKey) { mutableStateOf(uiState.authKey) }
  var showKeyHelp by remember { mutableStateOf(false) }

  val infiniteTransition = rememberInfiniteTransition(label = "pulse")
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 0.95f,
    targetValue = 1.08f,
    animationSpec = infiniteRepeatable(
      animation = tween(800, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulse_scale"
  )

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.94f)
        .padding(vertical = 20.dp)
        .testTag("mi_fit_device_dialog"),
      shape = RoundedCornerShape(28.dp),
      color = KestrelBg,
      tonalElevation = 8.dp,
      shadowElevation = 20.dp,
      border = androidx.compose.foundation.BorderStroke(1.dp, KestrelBorder)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        // --- Header Themed Exactly Like Kestrel Web App ---
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(44.dp)
                .background(
                  brush = Brush.linearGradient(
                    listOf(KestrelLilac, KestrelMauveDark)
                  ),
                  shape = CircleShape
                ),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Watch,
                contentDescription = "Mi Band",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "Mi Smart Band 5",
                color = KestrelText,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "Zepp Life Realtime Sync",
                color = KestrelMauveDark,
                fontSize = 12.sp
              )
            }
          }

          IconButton(
            onClick = onDismiss,
            modifier = Modifier.testTag("close_dialog_button")
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close",
              tint = KestrelMuted
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- Active Device Status Card ---
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = KestrelCard),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, KestrelBorder)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              val statusColor = when (uiState.status) {
                ConnectionStatus.CONNECTED -> Color(0xFF10B981)
                ConnectionStatus.CONNECTING, ConnectionStatus.AUTHENTICATING -> Color(0xFFF59E0B)
                ConnectionStatus.SCANNING -> KestrelMauve
                ConnectionStatus.DISCONNECTED -> Color(0xFF94A3B8)
              }

              Box(
                modifier = Modifier
                  .size(12.dp)
                  .background(statusColor, CircleShape)
                  .then(
                    if (uiState.status == ConnectionStatus.CONNECTING || uiState.status == ConnectionStatus.SCANNING) {
                      Modifier.scale(pulseScale)
                    } else Modifier
                  )
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = when (uiState.status) {
                    ConnectionStatus.CONNECTED -> "Connected"
                    ConnectionStatus.CONNECTING -> "Connecting..."
                    ConnectionStatus.AUTHENTICATING -> "Authenticating Band..."
                    ConnectionStatus.SCANNING -> "Scanning Nearby..."
                    ConnectionStatus.DISCONNECTED -> "Not Connected"
                  },
                  color = KestrelText,
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 15.sp
                )
                if (uiState.deviceName.isNotEmpty()) {
                  Text(
                    text = uiState.deviceName,
                    color = KestrelMauveDark,
                    fontSize = 12.sp
                  )
                }
              }
            }

            // Battery Level Badge
            if (uiState.batteryPercent >= 0) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                  .background(KestrelCardLight, RoundedCornerShape(12.dp))
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.BatteryChargingFull,
                  contentDescription = "Battery",
                  tint = if (uiState.batteryPercent > 20) Color(0xFF10B981) else Color(0xFFEF4444),
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "${uiState.batteryPercent}%",
                  color = KestrelText,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }

        // --- Live Health Metrics Grid (Realtime Band Telemetry) ---
        if (uiState.liveHeartRate > 0 || uiState.liveSteps > 0) {
          Spacer(modifier = Modifier.height(14.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            // Live Heart Rate Tile
            Card(
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(18.dp),
              colors = CardDefaults.cardColors(containerColor = KestrelCard),
              border = androidx.compose.foundation.BorderStroke(1.dp, KestrelBorder)
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text("Live Heart Rate", color = KestrelMauveDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                  Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = Color(0xFFF43F5E),
                    modifier = Modifier
                      .size(16.dp)
                      .scale(pulseScale)
                  )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                  Text(
                    text = if (uiState.liveHeartRate > 0) "${uiState.liveHeartRate}" else "–",
                    color = KestrelText,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("BPM", color = KestrelMuted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 3.dp))
                }
              }
            }

            // Live Steps Tile
            Card(
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(18.dp),
              colors = CardDefaults.cardColors(containerColor = KestrelCard),
              border = androidx.compose.foundation.BorderStroke(1.dp, KestrelBorder)
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text("Live Steps", color = KestrelMauveDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                  Icon(
                    imageVector = Icons.Default.DirectionsWalk,
                    contentDescription = null,
                    tint = Color(0xFF0284C7),
                    modifier = Modifier.size(16.dp)
                  )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = "%,d".format(uiState.liveSteps),
                  color = KestrelText,
                  fontSize = 22.sp,
                  fontWeight = FontWeight.ExtraBold
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- 16-byte Auth Key (Zepp Token) Section ---
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = KestrelCard),
          border = androidx.compose.foundation.BorderStroke(1.dp, KestrelBorder)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Key,
                  contentDescription = null,
                  tint = KestrelMauveDark,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "Zepp Auth Key (Optional)",
                  color = KestrelText,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }

              IconButton(
                onClick = { showKeyHelp = !showKeyHelp },
                modifier = Modifier.size(24.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Info,
                  contentDescription = "Help",
                  tint = KestrelMauveDark,
                  modifier = Modifier.size(16.dp)
                )
              }
            }

            AnimatedVisibility(visible = showKeyHelp) {
              Text(
                text = "If you extracted your 32-hex Auth Key from Zepp Life / Mi Fit, paste it here. If not, don't worry! You can pair directly via Standard BLE Pairing below.",
                color = KestrelMuted,
                fontSize = 11.sp,
                lineHeight = 16.sp,
                modifier = Modifier.padding(vertical = 6.dp)
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
              value = inputAuthKey,
              onValueChange = {
                inputAuthKey = it
                onSaveAuthKey(it)
              },
              placeholder = {
                Text(
                  text = "32 hex chars (Optional for pairing)",
                  color = KestrelMuted,
                  fontSize = 12.sp
                )
              },
              trailingIcon = {
                IconButton(
                  onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    val clip = clipboard?.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                    if (clip.isNotEmpty()) {
                      inputAuthKey = clip.trim()
                      onSaveAuthKey(clip.trim())
                    }
                  }
                ) {
                  Icon(
                    imageVector = Icons.Default.ContentPaste,
                    contentDescription = "Paste",
                    tint = KestrelMauveDark
                  )
                }
              },
              singleLine = true,
              modifier = Modifier
                .fillMaxWidth()
                .testTag("auth_key_text_field"),
              colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = KestrelText,
                unfocusedTextColor = KestrelText,
                focusedBorderColor = KestrelMauveDark,
                unfocusedBorderColor = KestrelBorder,
                focusedContainerColor = KestrelCardLight,
                unfocusedContainerColor = KestrelCardLight
              ),
              shape = RoundedCornerShape(12.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- Discovered Bands / Scanner Section ---
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Nearby Devices",
            color = KestrelText,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )

          if (uiState.status == ConnectionStatus.SCANNING) {
            OutlinedButton(
              onClick = onStopScanClick,
              shape = RoundedCornerShape(20.dp),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD97706)),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD97706))
            ) {
              CircularProgressIndicator(
                modifier = Modifier.size(12.dp),
                color = Color(0xFFD97706),
                strokeWidth = 2.dp
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text("Stop", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          } else {
            Button(
              onClick = onScanClick,
              shape = RoundedCornerShape(20.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = KestrelMauveDark,
                contentColor = Color.White
              ),
              modifier = Modifier.testTag("scan_bands_button")
            ) {
              Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = null,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text("Search Band", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Device List
        if (discoveredDevices.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(110.dp)
              .background(KestrelCard, RoundedCornerShape(16.dp))
              .border(1.dp, KestrelBorder, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
              Icon(
                imageVector = if (uiState.status == ConnectionStatus.SCANNING) Icons.Default.BluetoothSearching else Icons.Default.Bluetooth,
                contentDescription = null,
                tint = KestrelMauveDark,
                modifier = Modifier.size(24.dp)
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = if (uiState.status == ConnectionStatus.SCANNING) "Searching for Mi Band 5..." else "Tap 'Search Band' with phone Bluetooth & GPS ON",
                color = KestrelMuted,
                fontSize = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
              )
            }
          }
        } else {
          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .height(160.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(discoveredDevices) { band ->
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("discovered_device_${band.address}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                  containerColor = if (band.isMiBand) KestrelCardLight else Color.White
                ),
                border = androidx.compose.foundation.BorderStroke(
                  1.dp,
                  if (band.isMiBand) KestrelMauve else KestrelBorder
                )
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                  ) {
                    Icon(
                      imageVector = if (band.isMiBand) Icons.Default.Watch else Icons.Default.Bluetooth,
                      contentDescription = null,
                      tint = if (band.isMiBand) KestrelMauveDark else KestrelMauve,
                      modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                          text = band.name,
                          color = KestrelText,
                          fontWeight = FontWeight.Bold,
                          fontSize = 14.sp,
                          maxLines = 1,
                          overflow = TextOverflow.Ellipsis
                        )
                        if (band.isMiBand) {
                          Spacer(modifier = Modifier.width(6.dp))
                          Box(
                            modifier = Modifier
                              .background(Color(0xFF10B981).copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                              .padding(horizontal = 5.dp, vertical = 2.dp)
                          ) {
                            Text("Mi Band", color = Color(0xFF10B981), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                          }
                        }
                      }
                      Text(
                        text = "${band.address}  •  ${band.rssi} dBm",
                        color = KestrelMuted,
                        fontSize = 11.sp
                      )
                    }
                  }

                  // Pair / Connect Button
                  Button(
                    onClick = { onConnectClick(band, inputAuthKey) },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                      containerColor = if (band.isMiBand) KestrelMauveDark else KestrelMauve,
                      contentColor = Color.White
                    ),
                    modifier = Modifier.testTag("pair_device_button")
                  ) {
                    Text("Pair", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                  }
                }
              }
            }
          }
        }

        // Error message banner if any
        if (uiState.errorMessage != null) {
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = uiState.errorMessage,
            color = Color(0xFFDC2626),
            fontSize = 12.sp,
            lineHeight = 16.sp
          )
        }

        // Sync All Data & Re-run Setup Buttons
        Spacer(modifier = Modifier.height(14.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              onSyncAllDataClick()
              onDismiss()
            },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = Color(0xFF10B981),
              contentColor = Color.White
            )
          ) {
            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Sync All Data", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = {
              onDismiss()
              onReopenOnboarding()
            },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = KestrelMauveDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, KestrelMauveDark)
          ) {
            Text("Setup Wizard", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }

        // Disconnect Button if connected
        if (uiState.status == ConnectionStatus.CONNECTED) {
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedButton(
            onClick = onDisconnectClick,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("disconnect_band_button"),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444))
          ) {
            Text("Disconnect Mi Band", fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }
        }
      }
    }
  }
}
